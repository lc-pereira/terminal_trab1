#!/bin/bash

./trabalho.sh

./corretor
